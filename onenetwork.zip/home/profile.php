<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Collapsible sidebar using Bootstrap 4</title>

    <link rel="stylesheet" href="../vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../vendors/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="../vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="../vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="../vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="../vendors/jqvmap/dist/jqvmap.min.css">

    <link rel="stylesheet" href="../css/index.css">

</head>

<body>

    <div class="wrapper">
        <!-- Sidebar Holder -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <img src="../images/admin.jpg" class="logout" style="margin-left:20px;">
            </div>

            <div class="list-unstyled components">
                <center><p>NAME OF USER</p></center>
                <li>
                    <div>
                        <p>Username :
                            <kbd style="background: transparent;">201812101</kbd>   
                        </p>
                    </div>
                </li>
                <li>
                    <div class="form-group">
                        <label for="exampleFormControlInput2"><strong>Technologies</strong></label>
                        <div class="col-md-20" id="exampleFormControlInput2">
                                <label class="checkbox-inline">
                                    <input type="checkbox" value="" checked>Ambient intelligence
                                </label>

                                <label class="checkbox-inline">
                                    <input type="checkbox" value="" checked>Artificial brain
                                </label>

                                <label class="checkbox-inline">
                                    <input type="checkbox" value="">Blockchain
                                </label>

                        </div>
                    </div>
                </li>
                <li>
                    <div class="form-group">
                        <label for="exampleFormControlInput3"><strong>Languages</strong></label>
                        <div class="col-md-20" id="exampleFormControlInput3">
                            <label class="checkbox-inline">
                                <input type="checkbox" value="" checked>JAVA
                            </label>

                            <label class="checkbox-inline">
                                <input type="checkbox" value="" checked>PHP
                            </label>

                            <label class="checkbox-inline">
                                <input type="checkbox" value="" >MYSQL
                            </label>

                            <label class="checkbox-inline">
                                <input type="checkbox" value="" checked>HTML
                            </label>
                            <label class="checkbox-inline">
                                <input type="checkbox" value="" checked>JAVA
                            </label>

                            <label class="checkbox-inline">
                                <input type="checkbox" value="" >PHP
                            </label>

                            <label class="checkbox-inline">
                                <input type="checkbox" value="" checked>MYSQL
                            </label>

                            <label class="checkbox-inline">
                                <input type="checkbox" value="" checked>HTML
                            </label>
                        </div>
                    </div>
                </li>
            </div>
        </nav>
        <!-- Page Content Holder -->
        <div id="content">

           <?php require_once 'header.php'; ?>
            
            <div class="MainPannel Sections">
                <div class="container">
                    <form class="form-inline">
                        <i class="fa fa-search" aria-hidden="true"></i>
                        <input class="form-control form-control-sm ml-3 w-75" type="text" placeholder="Search Projects" aria-label="Search">
                    </form>
                    <ul class="nav nav-tabs navprofile">
                        <li class="active"><a data-toggle="tab" href="#applied">Applied</a></li>
                        <li><a data-toggle="tab" href="#posted">Posted</a></li>
                    </ul>
                    
                    <div class="tab-content">
                        <div id="applied" class="tab-pane fade in">
                            <center><h2>Applied Projects</h2></center>
                            <div class="ListOfProjects">
                                <div class="Boxy">
                                    <a href="#">
                                        <img class="user-avatar rounded-circle" src="../images/admin.jpg" alt="User Avatar"width: 50px height: 50px style="margin: 0%;margin-left: 5px;display: block; float: left">
                                    </a>
                                    <hr class="closehr">
                                    <p class="NameDescription">
                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                                    </p>
                                    <p>
                                        <button name="details_about_project" formmethod="" formaction="" class="details_btn">Details</button>
                                        <i class="tags">Andriod Artificial Intelligence Machine Learning</i>
                                    </p>
                                </div>
                                <div class="Boxy">
                                    <a href="#">
                                            <img class="user-avatar rounded-circle" src="../images/admin.jpg" alt="User Avatar"width: 50px height: 50px style="margin: 0%;margin-left: 5px;display: block; float: left">
                                        </a>
                                    <hr class="closehr">
                                    <p class="NameDescription">
                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                                    </p>
                                    <p>
                                        <button name="details_about_project" formmethod="" formaction="" class="details_btn">Details</button>
                                        <i class="tags">Andriod Artificial Intelligence Machine Learning</i>
                                    </p>
                                </div>
                                <div class="Boxy">
                                    <a href="#">
                                        <img class="user-avatar rounded-circle" src="../images/admin.jpg" alt="User Avatar"width: 50px height: 50px style="margin: 0%;margin-left: 5px;display: block; float: left">
                                    </a>
                                    <hr class="closehr">
                                    <p class="NameDescription">
                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                                    </p>
                                    <p>
                                        <button name="details_about_project" formmethod="" formaction="" class="details_btn">Details</button>
                                        <i class="tags">Andriod Artificial Intelligence Machine Learning</i>
                                    </p>
                                </div>
                            </div>
                        </div>


                        <div id="posted" class="tab-pane fade in">
                            <center><h2>Posted Projects</h2></center>
                            <div class="ListOfProjects">
                                <div class="Boxy">
                                    <a href="#">
                                        <img class="user-avatar rounded-circle" src="../images/admin.jpg" alt="User Avatar"width: 50px height: 50px style="margin: 0%;margin-left: 5px;display: block; float: left">
                                    </a>
                                    <p class="TitleName">Lorem Ipsum<img class="closeicon" src="../images/close.png"></p>
                                    <hr class="closehr">
                                    <p class="NameDescription">
                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                                    </p>
                                    <p>
                                        <button name="details_about_project" formmethod="" formaction="" class="details_btn">Details</button>
                                        <i class="tags">Andriod Artificial Intelligence Machine Learning</i>
                                    </p>
                                </div>
                                <div class="Boxy">
                                    <a href="#">
                                        <img class="user-avatar rounded-circle" src="../images/admin.jpg" alt="User Avatar"width: 50px height: 50px style="margin: 0%;margin-left: 5px;display: block; float: left">
                                    </a>
                                    <p class="TitleName">Lorem Ipsum<img class="closeicon" src="../images/close.png"></p>
                                    <hr class="closehr">
                                    <p class="NameDescription">
                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                                    </p>
                                    <p>
                                        <button name="details_about_project" formmethod="" formaction="" class="details_btn">Details</button>
                                        <i class="tags">Andriod Artificial Intelligence Machine Learning</i>
                                    </p>
                                </div>
                                <div class="Boxy">
                                    <a href="#">
                                        <img class="user-avatar rounded-circle" src="../images/admin.jpg" alt="User Avatar"width: 50px height: 50px style="margin: 0%;margin-left: 5px;display: block; float: left">
                                    </a>
                                    <p class="TitleName">Lorem Ipsum<img class="closeicon" src="../images/close.png"></p>
                                    <hr class="closehr">
                                    <p class="NameDescription">
                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                                    </p>
                                    <p>
                                        <button name="details_about_project" formmethod="" formaction="" class="details_btn">Details</button>
                                        <i class="tags">Andriod Artificial Intelligence Machine Learning</i>
                                    </p>
                                </div>
                                <div class="Boxy">
                                    <a href="#">
                                        <img class="user-avatar rounded-circle" src="../images/admin.jpg" alt="User Avatar"width: 50px height: 50px style="margin: 0%;margin-left: 5px;display: block; float: left">
                                    </a>
                                    <p class="TitleName">Lorem Ipsum<img class="closeicon" src="../images/close.png"></p>
                                    <hr class="closehr">
                                    <p class="NameDescription">
                                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                                    </p>
                                    <p>
                                        <button name="details_about_project" formmethod="" formaction="" class="details_btn">Details</button>
                                        <i class="tags">Andriod Artificial Intelligence Machine Learning</i>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="../vendors/jquery/dist/jquery.min.js"></script>
    <script src="../vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="../vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="../vendors/chart.js/dist/Chart.bundle.min.js"></script>
    <script src="../vendors/jqvmap/dist/jquery.vmap.min.js"></script>
    <script src="../vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <script src="../vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
                $(this).toggleClass('active');
            });
        });
    </script>
</body>

</html>